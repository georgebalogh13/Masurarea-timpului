import socket
import time

print("Start the stopwatch")
start = time.time()

server_port = 21060
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
input_s = 'Hello, server, here!'
large_input = "q,w,e,r,t,y,u,i,o,p,a,s,d,f,g,h,j,k,l,z,x,c,v,b,n,m"

even_larger_input=""
for i in range(1500):
    even_larger_input = even_larger_input + ",text" 


client_socket.sendto(bytes(even_larger_input, encoding='utf8'), ('127.0.0.1', server_port)) 
input_s_modified, address = client_socket.recvfrom(65535)
print('[CLIENT] Response from server {}, is: "{}"'.format(address, str(input_s_modified.decode('utf8'))))
client_socket.close()


end = time.time()
print("Time elapsed to get the response back : " + str(end - start))